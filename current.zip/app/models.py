from datetime import datetime, date
from flask_login import UserMixin
from .extensions import db


class User(db.Model, UserMixin):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    phone = db.Column(db.String(20))
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum("customer", "admin", name="user_role"), nullable=False, default="customer")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login_at = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    avatar_filename = db.Column(db.String(255), nullable=True)

    # Relationships (optional but useful later)
    expenses = db.relationship("Expense", back_populates="user", lazy=True)
    reminders = db.relationship("Reminder", back_populates="user", lazy=True)
    ci_calculations = db.relationship("CICalculation", back_populates="user", lazy=True)

    def __repr__(self):
        return f"<User {self.email} ({self.role})>"


class ExpenseCategory(db.Model):
    __tablename__ = "expense_categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    description = db.Column(db.String(255))
    is_default = db.Column(db.Boolean, default=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)  # for custom categories

    user = db.relationship("User", backref="custom_categories")
    expenses = db.relationship("Expense", back_populates="category", lazy=True)

    def __repr__(self):
        return f"<ExpenseCategory {self.name}>"


class Expense(db.Model):
    __tablename__ = "expenses"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("expense_categories.id"), nullable=True)
    title = db.Column(db.String(100))
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    expense_date = db.Column(db.Date, default=date.today)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.String(255))

    user = db.relationship("User", back_populates="expenses")
    category = db.relationship("ExpenseCategory", back_populates="expenses")

    def __repr__(self):
        return f"<Expense {self.title or ''} {self.amount}>"


class Reminder(db.Model):
    __tablename__ = "reminders"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    reminder_title = db.Column(db.String(150), nullable=False)
    reminder_date = db.Column(db.Date, nullable=False)
    note = db.Column(db.String(255))
    is_done = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User", back_populates="reminders")

    def __repr__(self):
        return f"<Reminder {self.reminder_title} on {self.reminder_date}>"


class CICalculation(db.Model):
    __tablename__ = "ci_calculations"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    principal = db.Column(db.Numeric(12, 2), nullable=False)
    rate = db.Column(db.Numeric(5, 2), nullable=False)
    years = db.Column(db.Integer, nullable=False)
    n_compounds = db.Column(db.Integer, default=1)
    maturity_amount = db.Column(db.Numeric(12, 2), nullable=False)
    total_interest = db.Column(db.Numeric(12, 2), nullable=False)
    calculated_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User", back_populates="ci_calculations")

    def __repr__(self):
        return f"<CICalc {self.principal} -> {self.maturity_amount}>"


class PageContent(db.Model):
    """
    Simple CMS table so admin can edit text for home/about/contact pages.
    """
    __tablename__ = "page_contents"

    id = db.Column(db.Integer, primary_key=True)
    page_slug = db.Column(db.String(50), nullable=False)   # 'home', 'about', 'contact'
    section_name = db.Column(db.String(50), nullable=False)  # 'hero_title', etc.
    content = db.Column(db.Text, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    updated_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    updated_by_user = db.relationship("User")

    def __repr__(self):
        return f"<PageContent {self.page_slug}:{self.section_name}>"
