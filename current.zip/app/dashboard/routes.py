# app/dashboard/routes.py
from flask import redirect, url_for, render_template
from flask_login import login_required, current_user

from . import dashboard_bp


@dashboard_bp.route("/")
@login_required
def home():
    # Default tab – you can change to 'overview' if you prefer
    return redirect(url_for("dashboard.profile"))


@dashboard_bp.route("/profile")
@login_required
def profile():
    return render_template("dashboard/profile.html")


@dashboard_bp.route("/expenses")
@login_required
def expenses():
    return render_template("dashboard/expenses.html")


@dashboard_bp.route("/compound")
@login_required
def compound():
    return render_template("dashboard/compound.html")


@dashboard_bp.route("/advisor")
@login_required
def advisor():
    return render_template("dashboard/advisor.html")


@dashboard_bp.route("/calendar")
@login_required
def calendar():
    return render_template("dashboard/calendar.html")


@dashboard_bp.route("/overview")
@login_required
def overview():
    return render_template("dashboard/overview.html")
